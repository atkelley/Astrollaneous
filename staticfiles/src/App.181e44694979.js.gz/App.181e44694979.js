import React, { Component } from 'react';


class App extends Component {

  render() {
    return (
      <div className="container">
        APP
      </div>
    );
  }
}

export default App;